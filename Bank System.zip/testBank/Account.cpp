
#include "Account.h"
#include <cmath>
#include <iostream>
using namespace std;

namespace BankSystem {

	double Account::total = 0;

	Account::Account(const Date &date, const string &id) :
		id(id), balance(0) {
		//date.show();
		cout << date << " ";
		cout << "\t#" << id << " created" << endl;
	}
	void Account::record(const Date &date, double amount, const string &desc) {
		amount = floor(amount * 100 + 0.5) / 100; //����С�������λ
		balance += amount;
		total += amount;
		//date.show();
		cout << date;
		cout << "\t#" << id << "\t" << amount << "\t" << balance << "\t" << desc
			<< endl;
	}
	void Account::show() const {
		cout << id << "\tBalance: " << balance;
	}
	void Account::error(const string &msg) const {
		cout << "Error(#" << id << "): " << msg << endl;
	}

	//���������
	ostream & operator <<(ostream & os, const Account& account) {
		//os << account.getId() << "\tBalance: " << account.getBalance();
		os << "�˻�  " << account.getId() << "\t���: " << account.getBalance();

		return os;
	}


}
